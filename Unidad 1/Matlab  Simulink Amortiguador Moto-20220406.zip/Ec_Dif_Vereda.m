%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%
%%% Ec. Dif. Modelo Amortiguador de Moto (Cord�n)
%%%
%%% Sistemas de Control
%%%
%%% Dr. Ing. Franco Martin Pessana
%%% FRBA
%%% Universidad Tecnol�gica Nacional
%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function Xp = Ec_Dif_Vereda(t,X,m,b,k)

xv = 0.15; % m

a0 = k/m;
a1 = b/m;

A = [0 1;-a0 -a1];
B = [0;1];
Xp = A*X + B*xv;