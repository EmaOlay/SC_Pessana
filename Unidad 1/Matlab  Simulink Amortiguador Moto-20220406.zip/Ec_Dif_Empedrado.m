%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%
%%% Ec. Dif. Modelo Amortiguador de Moto (Empedrado)
%%%
%%% Sistemas de Control
%%%
%%% Dr. Ing. Franco Martin Pessana
%%% FRBA
%%% Universidad Tecnol�gica Nacional
%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function Xp = Ec_Dif_Empedrado(t,X,m,b,k,T0)


if rem(t,T0)<=T0/2
    xv = 0.15; % m
else
    xv = -0.15; % m
end

a0 = k/m;
a1 = b/m;

A = [0 1;-a0 -a1];
B = [0;1];

Xp = A*X + B*xv;