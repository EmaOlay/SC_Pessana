%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%
%%% Ejemplo Global Representaci�n Sistemas SISO
%%%
%%% M�todo#3. Estados Naturales.
%%%
%%% Sistemas de Control
%%%
%%% Dr. Ing. Franco Martin Pessana
%%% FRBA
%%% Universidad Tecnol�gica Nacional
%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear
clc

m = 200; % Kg
b = 50; % N.s/m
k = 100; % N/m
xv = 0.15; % m
T0 = 5; % Per�odo de oscilaci�n del empedrado (s)
t0 = 0; % Tiempo Inicial de An�lisis (s)
tF = 60; % Tiempo Final de An�lisis (s)
Dt = 0.1; % Intervalo de an�lisis
X0 = [0 0]';

% Modelo de Estados Naturales
A = [0 -k;1/m -b/m];
B = [k b/m]';
C = [0 1];
D = [0];
[NG,DG] = ss2tf(A,B,C,D);
disp('Transferencia del Amortiguador a partir del Modelos de Estados:')
G = tf(NG,DG)

M_Est_Nat = ss(A,B,C,D); % Puntero al Modelo de Estados
t = t0:Dt:tF; % Generaci�n de eje temporal
cordon=xv*ones(size(t)); % Cord�n de la vereda
y_cordon = lsim(M_Est_Nat,cordon,t,X0);
empedrado = xv*square(2*pi*t/T0,50); % Calle de empedrado
y_empedrado = lsim(M_Est_Nat,empedrado,t,X0);

H1=figure(1);
set(H1,'name','Estados Naturales Amortiguador Moto (Cord�n Vereda)','position',[10 20 1450 800],...
    'menubar','none');
plot(t,cordon,'r',t,y_cordon,'b')
xlabel('t (seg.)')
ylabel('y(t) (m)')
legend('x(t)','y(t)')
grid;

H2=figure(2);
set(H2,'name','Estados Naturales Amortiguador Moto (Empedrado)','position',[50 20 1450 800],...
    'menubar','none');
plot(t,empedrado,'r',t,y_empedrado,'b')
xlabel('t (seg.)')
ylabel('y(t) (m)')
legend('x(t)','y(t)')
grid;