%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%
%%% Ejemplo Global Representaci�n Sistemas SISO
%%%
%%% M�todo#6. Simulaci�n Bloques con Simulink
%%%
%%% Sistemas de Control
%%%
%%% Dr. Ing. Franco Martin Pessana
%%% FRBA
%%% Universidad Tecnol�gica Nacional
%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear
clc

m = 200; % Kg
b = 50; % N.s/m
k = 100; % N/m
xv = 0.15; % m
T0 = 5; % Per�odo de oscilaci�n del empedrado (s)
