%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%
%%% Ejemplo Global Representaci�n Sistemas SISO
%%%
%%% M�todo#1. Resoluci�n N�merica de la Ec. Dif.
%%%
%%% Sistemas de Control
%%%
%%% Dr. Ing. Franco Martin Pessana
%%% FRBA
%%% Universidad Tecnol�gica Nacional
%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear
clc

m = 200; % Kg
b = 50; % N.s/m
k = 100; % N/m
xv = 0.15; % m
T0 = 5; % Per�odo de oscilaci�n del empedrado (s)
t0 = 0; % Tiempo Inicial de An�lisis (s)
tf = 60; % Tiempo Final de An�lisis (s)
X0 = [0 0]'; % Condiciones iniciales de la Ec. DIf.

[t1,X1] = ode45(@(t,X1) Ec_Dif_Vereda(t,X1,m,b,k),[t0 tf],X0);
C = [k/m b/m];
y_cordon = C*X1';
y_cordon = y_cordon';
cordon=xv*ones(size(t1));

[t2,X2] = ode45(@(t,X2) Ec_Dif_Empedrado(t,X2,m,b,k,T0),[t0 tf],X0);
y_empedrado = C*X2';
y_empedrado = y_empedrado';
empedrado = xv*square(2*pi*t2/T0,50);

H1=figure(1);
set(H1,'name','Resoluci�n Num�rica Ec. Dif. Amortiguador Moto (Cord�n Vereda)','position',[10 20 1450 800],...
    'menubar','none');
plot(t1,cordon,'r',t1,y_cordon,'b')
xlabel('t (seg.)')
ylabel('y(t) (m)')
legend('x(t)','y(t)')
grid;

H2=figure(2);
set(H2,'name','Resoluci�n Num�rica Ec. Dif. Amortiguador Moto (Empedrado)','position',[50 20 1450 800],...
    'menubar','none');
plot(t2,empedrado,'r',t2,y_empedrado,'b')
xlabel('t (seg.)')
ylabel('y(t) (m)')
legend('x(t)','y(t)')
grid;